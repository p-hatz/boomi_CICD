def query():
    return {
        "QueryFilter": {
            "expression": {
                "argument": [""],
                "operator": "EQUALS", 
                "property": "name"
            }
        }
    }
