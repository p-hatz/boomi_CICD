import json


def execute():
    data = json.loads(
        """
        {
            "listenerId": "",
            "containerId": "",
            "action": ""
        }"""
    )
    return data
