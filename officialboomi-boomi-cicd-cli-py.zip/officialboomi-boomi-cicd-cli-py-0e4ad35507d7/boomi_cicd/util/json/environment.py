def query():
    data = {
        "QueryFilter": {
            "expression": {"argument": [""], "operator": "EQUALS", "property": "name"}
        }
    }
    return data
