import json
import pytest
from unittest.mock import Mock, patch
import boomi_cicd


class TestQueryAtom:
    """Test cases for the query_atom function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_query_atom_success(self, mock_atomsphere_request):
        """Test query_atom returns correct atom ID when atom exists."""
        # Mock response data
        mock_response_data = {
            "@type": "QueryResult",
            "result": [
                {
                    "@type": "Atom",
                    "capabilities": [],
                    "id": "8a0a749b-4e1f-45c8-b5cc-e637f7c282e5",
                    "name": "Test Atom",
                    "status": "ONLINE",
                    "type": "MOLECULE",
                    "hostName": "localhost",
                    "dateInstalled": "2022-05-11T03:17:09Z",
                    "currentVersion": "23.04.2",
                    "purgeHistoryDays": 1,
                    "purgeImmediate": "false",
                    "forceRestartTime": 900000,
                }
            ],
            "numberOfResults": 1,
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.query_atom("Test Atom")
        
        # Assertions
        assert result == "8a0a749b-4e1f-45c8-b5cc-e637f7c282e5"
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "argument": ["Test Atom"],
                    "operator": "EQUALS",
                    "property": "name",
                }
            }
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/Atom/query",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_query_atom_not_found(self, mock_atomsphere_request):
        """Test query_atom raises ValueError when atom doesn't exist."""
        # Mock response with no results
        mock_response_data = {
            "@type": "QueryResult",
            "result": [],
            "numberOfResults": 0
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test that ValueError is raised
        with pytest.raises(ValueError, match="Atom not found. Atom Name: Fake Atom"):
            boomi_cicd.query_atom("Fake Atom")
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "argument": ["Fake Atom"],
                    "operator": "EQUALS",
                    "property": "name",
                }
            }
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/Atom/query",
            payload=expected_payload
        )
