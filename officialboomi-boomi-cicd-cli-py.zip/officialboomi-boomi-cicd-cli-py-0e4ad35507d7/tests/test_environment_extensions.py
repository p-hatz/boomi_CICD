import json
import pytest
from unittest.mock import Mock, patch
import boomi_cicd


class TestEnvironmentExtensions:
    """Test cases for the environment extensions functions."""

    @patch('boomi_cicd.atomsphere_request')
    def test_get_environment_extensions(self, mock_atomsphere_request):
        """Test get_environment_extensions returns correct extensions data."""
        # Mock response data
        mock_response_data = {
            "@type": "EnvironmentExtensions",
            "environmentId": "c5256e0d-a9fe-4f8d-afe9-66dc7f016083",
            "extensionGroupId": "",
            "id": "c5256e0d-a9fe-4f8d-afe9-66dc7f016083",
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.get_environment_extensions("04490020-7c27-4972-b58f-917dd5e241bd")
        
        # Assertions
        assert result == mock_response_data
        
        # Verify the atomsphere_request was called with correct parameters
        mock_atomsphere_request.assert_called_once_with(
            method="get",
            resource_path="/EnvironmentExtensions/04490020-7c27-4972-b58f-917dd5e241bd"
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_update_environment_extensions(self, mock_atomsphere_request):
        """Test update_environment_extensions returns correct response data."""
        # Mock payload
        mock_payload = {
            "@type": "EnvironmentExtensions",
            "processProperties": {
                "@type": "OverrideProcessProperties",
                "ProcessProperty": [
                    {
                        "@type": "OverrideProcessProperty",
                        "ProcessPropertyValue": [
                            {
                                "@type": "ProcessPropertyValue",
                                "label": "String",
                                "key": "new-1355426770730",
                                "encryptedValueSet": False,
                                "useDefault": False,
                                "value": "Partialupdates",
                            },
                            {
                                "@type": "ProcessPropertyValue",
                                "label": "Password",
                                "key": "new-1355426788553",
                                "value": "PasswordUpdated",
                                "encryptedValueSet": False,
                                "useDefault": False,
                            },
                        ],
                        "id": "24a56789...",
                        "name": "Boomi Test",
                    }
                ],
            },
            "environmentId": "456789ab...",
            "extensionGroupId": "",
            "id": "6f678d09...",
            "partial": True,
        }
        
        # Mock response data
        mock_response_data = {
            "@type": "EnvironmentExtensions",
            "processProperties": {
                "@type": "OverrideProcessProperties",
                "ProcessProperty": [
                    {
                        "@type": "OverrideProcessProperty",
                        "ProcessPropertyValue": [
                            {
                                "@type": "ProcessPropertyValue",
                                "label": "String",
                                "key": "68dad3cb...",
                                "value": "Partialupdates",
                                "encryptedValueSet": False,
                                "useDefault": False,
                            },
                            {
                                "@type": "ProcessPropertyValue",
                                "label": "Password",
                                "key": "af61be8f...",
                                "value": "PasswordUpdated",
                                "encryptedValueSet": False,
                                "useDefault": False,
                            },
                        ],
                        "id": "23a30680...",
                        "name": "Test Some Props Yo",
                    }
                ],
            },
            "environmentId": "456789ab...",
            "extensionGroupId": "",
            "id": "6f678d09...",
            "partial": True,
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.update_environment_extensions("04490020-7c27-4972-b58f-917dd5e241bd", mock_payload)
        
        # Assertions
        assert result == mock_response_data
        
        # Verify the atomsphere_request was called with correct parameters
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/EnvironmentExtensions/04490020-7c27-4972-b58f-917dd5e241bd/update",
            payload=mock_payload
        )
