import json
import pytest
from unittest.mock import Mock, patch
import boomi_cicd


class TestQueryEnvironment:
    """Test cases for the query_environment function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_query_environment_success(self, mock_atomsphere_request):
        """Test query_environment returns correct environment ID when environment exists."""
        # Mock response data
        mock_response_data = {
            "@type": "QueryResult",
            "result": [
                {
                    "@type": "Environment",
                    "id": "13da4a90-53f4-4396-b63d-83ef772ee8d",
                    "name": "Test Cloud Environment",
                    "classification": "TEST",
                }
            ],
            "numberOfResults": 1,
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.query_environment("Test Cloud Environment")
        
        # Assertions
        assert result == "13da4a90-53f4-4396-b63d-83ef772ee8d"
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "argument": ["Test Cloud Environment"],
                    "operator": "EQUALS",
                    "property": "name",
                }
            }
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/Environment/query",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_query_environment_not_found(self, mock_atomsphere_request):
        """Test query_environment raises ValueError when environment doesn't exist."""
        # Mock response with no results
        mock_response_data = {
            "@type": "QueryResult",
            "result": [],
            "numberOfResults": 0
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test that ValueError is raised
        with pytest.raises(ValueError, match="Environment not found. Environment Name: Fake Environment"):
            boomi_cicd.query_environment("Fake Environment")
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "argument": ["Fake Environment"],
                    "operator": "EQUALS",
                    "property": "name",
                }
            }
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/Environment/query",
            payload=expected_payload
        )
