import json
import pytest
import time
from unittest.mock import patch, MagicMock
import requests
import boomi_cicd
from boomi_cicd.util.common_util import atomsphere_request


def test_parse_json(tmpdir):
    # Create a temporary file with some JSON data
    test_data = {"name": "test", "value": 42}
    test_file = tmpdir.join("test.json")
    test_file.write(json.dumps(test_data))

    # Test the function
    result = boomi_cicd.parse_json(str(test_file))
    assert result == test_data


def test_parse_json_no_file():
    # Test that the function raises a FileNotFoundError
    with pytest.raises(FileNotFoundError):
        boomi_cicd.parse_json("nonexistent/file.json")


def test_parse_json_invalid_json(tmpdir):
    # Create a temporary file with invalid JSON data
    test_file = tmpdir.join("invalid.json")
    test_file.write("not valid json")

    # Test that the function raises a JSONDecodeError
    with pytest.raises(json.JSONDecodeError):
        boomi_cicd.parse_json(str(test_file))


class TestAtomSphereRequestRateLimit:
    """Test rate limiting functionality for atomsphere_request function."""

    @patch('boomi_cicd.BASE_URL', 'https://api.boomi.com')
    @patch('boomi_cicd.ACCOUNT_ID', 'test_account')
    @patch('boomi_cicd.USERNAME', 'test_user')
    @patch('boomi_cicd.PASSWORD', 'test_pass')
    @patch('boomi_cicd.CALLS_PER_SECOND', 2)  # Set low limit for testing
    @patch('boomi_cicd.RATE_LIMIT_SECONDS', 1)
    def test_rate_limit_enforcement(self):
        """Test that rate limiting is enforced by checking decorator presence."""
        from ratelimit import limits, sleep_and_retry
        from retrying import retry
        
        # Check that the function has the expected decorators
        # The function should be wrapped by these decorators
        func = atomsphere_request
        
        # The function should have rate limiting applied
        # We can verify this by checking if the function has been wrapped
        assert hasattr(func, '__wrapped__'), "Function should be wrapped by decorators"
        
        # Test with a real but failing request to see rate limiting in action
        with patch('boomi_cicd.util.common_util.requests.get') as mock_get:
            mock_response = MagicMock()
            mock_response.text = '{"status": "success"}'
            mock_response.raise_for_status.return_value = None
            mock_get.return_value = mock_response
            
            # Make multiple calls and verify they complete
            # (The actual timing test is hard to do reliably in unit tests)
            start_time = time.time()
            
            # Make calls within the limit
            atomsphere_request(method="get", resource_path="/test1")
            atomsphere_request(method="get", resource_path="/test2")
            
            elapsed_time = time.time() - start_time
            
            # Verify requests were made
            assert mock_get.call_count == 2
            
            # The calls should complete relatively quickly since we're within limits
            assert elapsed_time < 2.0, f"Calls within limit took too long: {elapsed_time}"
            

    @patch('boomi_cicd.util.common_util.requests')
    @patch('boomi_cicd.BASE_URL', 'https://api.boomi.com')
    @patch('boomi_cicd.ACCOUNT_ID', 'test_account')
    @patch('boomi_cicd.USERNAME', 'test_user')
    @patch('boomi_cicd.PASSWORD', 'test_pass')
    def test_retry_on_503_error(self, mock_requests):
        """Test that 503 errors trigger retry mechanism."""
        # Mock 503 response for first two calls, success on third
        mock_503_response = MagicMock()
        mock_503_response.status_code = 503
        mock_503_response.text = 'Service Unavailable'
        mock_503_response.raise_for_status.side_effect = requests.HTTPError("503 Service Unavailable")

        mock_success_response = MagicMock()
        mock_success_response.status_code = 200
        mock_success_response.text = '{"status": "success"}'
        mock_success_response.raise_for_status.return_value = None

        # Configure mock to return 503 twice, then 200
        mock_requests.get.side_effect = [mock_503_response, mock_503_response, mock_success_response]

        # This should succeed after retries
        response = atomsphere_request(
            method="get",
            resource_path="/test/endpoint"
        )

        # Should have made 3 calls total (2 retries + 1 success)
        assert mock_requests.get.call_count == 3
        assert response.status_code == 200

    @patch('boomi_cicd.util.common_util.requests')
    @patch('boomi_cicd.BASE_URL', 'https://api.boomi.com')
    @patch('boomi_cicd.ACCOUNT_ID', 'test_account')
    @patch('boomi_cicd.USERNAME', 'test_user')
    @patch('boomi_cicd.PASSWORD', 'test_pass')
    def test_proper_headers_and_auth(self, mock_requests):
        """Test that proper headers and authentication are set."""
        mock_response = MagicMock()
        mock_response.text = '{"status": "success"}'
        mock_response.raise_for_status.return_value = None
        mock_requests.get.return_value = mock_response

        # Test with JSON payload
        test_payload = {"test": "data"}
        atomsphere_request(
            method="get",
            resource_path="/test/endpoint",
            payload=test_payload
        )

        # Verify the call was made with correct parameters
        mock_requests.get.assert_called_once()
        call_args = mock_requests.get.call_args

        # Check URL construction - URL is the first positional argument
        expected_url = "https://api.boomi.com/test_account/test/endpoint"
        actual_url = call_args[0][0]  # First positional argument
        assert actual_url == expected_url

        # Check authentication - keyword arguments
        assert call_args.kwargs['auth'] == ('test_user', 'test_pass')

        # Check headers
        expected_headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        assert call_args.kwargs['headers'] == expected_headers

        # Check payload
        assert call_args.kwargs['data'] == json.dumps(test_payload)

    @patch('boomi_cicd.util.common_util.requests')
    @patch('boomi_cicd.BASE_URL', 'https://api.boomi.com')
    @patch('boomi_cicd.ACCOUNT_ID', 'test_account')
    @patch('boomi_cicd.USERNAME', 'test_user')
    @patch('boomi_cicd.PASSWORD', 'test_pass')
    def test_xml_content_type(self, mock_requests):
        """Test that XML content type is handled correctly."""
        mock_response = MagicMock()
        mock_response.text = '<response>success</response>'
        mock_response.raise_for_status.return_value = None
        mock_requests.post.return_value = mock_response

        xml_payload = '<test>data</test>'
        atomsphere_request(
            method="post",
            resource_path="/test/endpoint",
            payload=xml_payload,
            accept_header="application/xml"
        )

        call_args = mock_requests.post.call_args
        expected_headers = {
            "Accept": "application/xml",
            "Content-Type": "application/xml"
        }
        assert call_args.kwargs['headers'] == expected_headers

    @patch('boomi_cicd.util.common_util.requests')
    @patch('boomi_cicd.BASE_URL', 'https://api.boomi.com')
    @patch('boomi_cicd.ACCOUNT_ID', 'test_account')
    @patch('boomi_cicd.USERNAME', 'test_user')
    @patch('boomi_cicd.PASSWORD', 'test_pass')
    def test_pass_error_functionality(self, mock_requests):
        """Test that errors can be passed through when pass_error=True."""
        mock_response = MagicMock()
        mock_response.status_code = 400
        mock_response.text = 'Bad Request'
        mock_response.raise_for_status.side_effect = requests.HTTPError("400 Bad Request")
        mock_requests.get.return_value = mock_response

        # With pass_error=False (default), should raise exception
        with pytest.raises(requests.HTTPError):
            atomsphere_request(
                method="get",
                resource_path="/test/endpoint",
                pass_error=False
            )

        # With pass_error=True, should return response without raising
        response = atomsphere_request(
            method="get",
            resource_path="/test/endpoint",
            pass_error=True
        )
        assert response.status_code == 400
