import json
import pytest
from unittest.mock import Mock, patch
from requests import HTTPError

import boomi_cicd


class TestChangeListenerStatus:
    """Test cases for the change_listener_status function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_change_listener_status_success(self, mock_atomsphere_request):
        """Test change_listener_status returns True when successful."""
        # Create mock response object (empty response for successful status change)
        mock_response = Mock()
        mock_response.text = ""
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.change_listener_status(
            "1234567890", 
            "8a0a749b-4e1f-45c8-b5cc-e637f7c282e5", 
            "RESUME"
        )
        
        # Assertions
        assert result is True
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "listenerId": "1234567890",
            "containerId": "8a0a749b-4e1f-45c8-b5cc-e637f7c282e5",
            "action": "RESUME",
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/changeListenerStatus",
            payload=expected_payload
        )
