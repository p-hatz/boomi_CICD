import json
import pytest
from unittest.mock import Mock, patch
import boomi_cicd


class TestCreateDeployedPackage:
    """Test cases for the create_deployed_package function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_create_deployed_package_success(self, mock_atomsphere_request):
        """Test create_deployed_package returns correct deployment ID when successful."""
        # Mock response data
        mock_response_data = {
            "@type": "DeployedPackage",
            "deploymentId": "dep-12345-67890",
            "environmentId": "env-123",
            "packageId": "pkg-456",
            "notes": "Test deployment",
            "listenerStatus": "RUNNING",
            "deployedDate": "2025-12-21T10:30:00Z"
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test data
        release = {
            "notes": "Test deployment",
            "listenerStatus": "RUNNING"
        }
        
        # Test the function
        result = boomi_cicd.create_deployed_package(release, "pkg-456", "env-123")
        
        # Assertions
        assert result == "dep-12345-67890"
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "environmentId": "env-123",
            "packageId": "pkg-456",
            "notes": "Test deployment",
            "listenerStatus": "RUNNING"
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/DeployedPackage",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_create_deployed_package_without_listener_status(self, mock_atomsphere_request):
        """Test create_deployed_package when release doesn't have listenerStatus."""
        # Mock response data
        mock_response_data = {
            "@type": "DeployedPackage",
            "deploymentId": "dep-98765-43210",
            "environmentId": "env-789",
            "packageId": "pkg-012",
            "notes": "Simple deployment"
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test data without listenerStatus
        release = {
            "notes": "Simple deployment"
        }
        
        # Test the function
        result = boomi_cicd.create_deployed_package(release, "pkg-012", "env-789")
        
        # Assertions
        assert result == "dep-98765-43210"
        
        # Verify the atomsphere_request was called with correct parameters (None listenerStatus)
        expected_payload = {
            "environmentId": "env-789",
            "packageId": "pkg-012",
            "notes": "Simple deployment"
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/DeployedPackage",
            payload=expected_payload
        )


class TestQueryDeployedPackage:
    """Test cases for the query_deployed_package function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_query_deployed_package_found(self, mock_atomsphere_request):
        """Test query_deployed_package returns True when package is found."""
        # Mock response data with results
        mock_response_data = {
            "@type": "QueryResult",
            "result": [
                {
                    "@type": "DeployedPackage",
                    "deploymentId": "dep-12345",
                    "environmentId": "env-123",
                    "packageId": "pkg-456",
                    "active": True
                }
            ],
            "numberOfResults": 1
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.query_deployed_package("pkg-456", "env-123", currently_deployed=True)
        
        # Assertions
        assert result is True
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "operator": "and",
                    "nestedExpression": [
                        {
                            "argument": ["env-123"],
                            "operator": "EQUALS",
                            "property": "environmentId"
                        },
                        {
                            "argument": ["pkg-456"],
                            "operator": "EQUALS",
                            "property": "packageId"
                        },
                        {
                            "argument": [True],
                            "operator": "EQUALS",
                            "property": "active"
                        }
                    ]
                }
            }
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/DeployedPackage/query",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_query_deployed_package_not_found(self, mock_atomsphere_request):
        """Test query_deployed_package returns False when package is not found."""
        # Mock response data with no results
        mock_response_data = {
            "@type": "QueryResult",
            "result": [],
            "numberOfResults": 0
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.query_deployed_package("pkg-999", "env-999", currently_deployed=True)
        
        # Assertions
        assert result is False
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "operator": "and",
                    "nestedExpression": [
                        {
                            "argument": ["env-999"],
                            "operator": "EQUALS",
                            "property": "environmentId"
                        },
                        {
                            "argument": ["pkg-999"],
                            "operator": "EQUALS",
                            "property": "packageId"
                        },
                        {
                            "argument": [True],
                            "operator": "EQUALS",
                            "property": "active"
                        }
                    ]
                }
            }
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/DeployedPackage/query",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_query_deployed_package_all_packages(self, mock_atomsphere_request):
        """Test query_deployed_package when currently_deployed=False (all packages)."""
        # Mock response data
        mock_response_data = {
            "@type": "QueryResult",
            "result": [
                {
                    "@type": "DeployedPackage",
                    "deploymentId": "dep-111",
                    "active": False
                }
            ],
            "numberOfResults": 1
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function with currently_deployed=False
        result = boomi_cicd.query_deployed_package("pkg-111", "env-111", currently_deployed=False)
        
        # Assertions
        assert result is True
        
        # Verify the atomsphere_request was called without active status filter
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "operator": "and",
                    "nestedExpression": [
                        {
                            "argument": ["env-111"],
                            "operator": "EQUALS",
                            "property": "environmentId"
                        },
                        {
                            "argument": ["pkg-111"],
                            "operator": "EQUALS",
                            "property": "packageId"
                        }
                    ]
                }
            }
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/DeployedPackage/query",
            payload=expected_payload
        )


class TestDeleteDeployedPackage:
    """Test cases for the delete_deployed_package function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_delete_deployed_package_with_response_text(self, mock_atomsphere_request):
        """Test delete_deployed_package with actual response text."""
        # Create mock response object with response text
        mock_response = Mock()
        mock_response.text = "Package deleted successfully"
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.delete_deployed_package("dep-98765-43210")
        
        # Assertions
        assert result == "Package deleted successfully"
        
        # Verify the atomsphere_request was called with correct parameters
        mock_atomsphere_request.assert_called_once_with(
            method="delete",
            resource_path="/DeployedPackage/dep-98765-43210"
        )