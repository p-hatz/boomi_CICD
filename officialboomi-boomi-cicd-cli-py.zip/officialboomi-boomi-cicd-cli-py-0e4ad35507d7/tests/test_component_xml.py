import os
import shutil
from unittest.mock import patch, Mock

import pytest
import boomi_cicd


# TODO: Mock clone_repository()


@pytest.mark.parametrize("platform_name,expected_dir,expected_zip", [
    ("Linux", "sonar-scanner-4.8.0.2856-linux", "sonar-scanner-cli-4.8.0.2856-linux.zip"),
    ("Windows", "sonar-scanner-4.8.0.2856-windows", "sonar-scanner-cli-4.8.0.2856-windows.zip")
])
@patch("boomi_cicd.util.component_xml.requests.get")
@patch("boomi_cicd.util.component_xml.ZipFile")
@patch("boomi_cicd.util.component_xml.platform.system")
@patch("builtins.open", create=True)
def test_install_sonarqube(mock_open, mock_platform, mock_zipfile, mock_requests, platform_name, expected_dir, expected_zip):
    # Mock platform detection
    mock_platform.return_value = platform_name
    
    # Mock HTTP response
    mock_response = Mock()
    mock_response.content = b"fake zip content"
    mock_requests.return_value = mock_response
    
    # Mock file writing
    mock_file = Mock()
    mock_open.return_value.__enter__.return_value = mock_file
    
    # Mock ZipFile extraction
    mock_zip_instance = Mock()
    mock_zipfile.return_value.__enter__.return_value = mock_zip_instance
    
    # Test the function
    result = boomi_cicd.install_sonarqube()
    
    # Verify expected behavior
    assert result == expected_dir
    
    # Verify HTTP request was made with correct URL
    expected_url = f"https://binaries.sonarsource.com/Distribution/sonar-scanner-cli/{expected_zip}"
    mock_requests.assert_called_once_with(expected_url, allow_redirects=True)
    
    # Verify file was opened for writing with correct filename
    mock_open.assert_called_once_with(expected_zip, "wb")
    
    # Verify file content was written
    mock_file.write.assert_called_once_with(b"fake zip content")
    
    # Verify zip extraction was called
    mock_zipfile.assert_called_once_with(expected_zip, "r")
    mock_zip_instance.extractall.assert_called_once()


@patch("boomi_cicd.util.component_xml.platform.system")
def test_install_sonarqube_unsupported_os(mock_platform):
    # Test unsupported OS error handling
    mock_platform.return_value = "Darwin"  # macOS - unsupported
    
    with pytest.raises(OSError, match="Unsupported OS: Darwin"):
        boomi_cicd.install_sonarqube()


def remove_directory(path):
    try:
        shutil.rmtree(path, ignore_errors=False)
    except Exception as e:
        print(f"Error: {e}")
