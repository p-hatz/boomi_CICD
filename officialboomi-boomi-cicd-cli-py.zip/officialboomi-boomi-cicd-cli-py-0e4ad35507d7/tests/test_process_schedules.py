import json
import pytest
import sys
from unittest.mock import Mock, patch
import boomi_cicd


class TestQueryProcessSchedules:
    """Test cases for the query_process_schedules function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_query_process_schedules_success(self, mock_atomsphere_request):
        """Test query_process_schedules returns correct conceptual ID when successful."""
        # Mock response data
        mock_response_data = {
            "@type": "QueryResult",
            "result": [
                {
                    "@type": "ProcessSchedules",
                    "id": "conceptual-12345-67890",
                    "processId": "process-123",
                    "atomId": "atom-456",
                    "Schedule": []
                }
            ],
            "numberOfResults": 1
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.query_process_schedules("atom-456", "process-123")
        
        # Assertions
        assert result == "conceptual-12345-67890"
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "operator": "and",
                    "nestedExpression": [
                        {
                            "argument": ["atom-456"],
                            "operator": "EQUALS",
                            "property": "atomId"
                        },
                        {
                            "argument": ["process-123"],
                            "operator": "EQUALS",
                            "property": "processId"
                        }
                    ]
                }
            }
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/ProcessSchedules/query",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_query_process_schedules_not_deployed(self, mock_atomsphere_request):
        """Test query_process_schedules exits when process is not deployed."""
        # Mock response data with no results
        mock_response_data = {
            "@type": "QueryResult",
            "result": [],
            "numberOfResults": 0
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function - should call sys.exit(1) which raises SystemExit
        with pytest.raises(SystemExit) as excinfo:
            boomi_cicd.query_process_schedules("atom-999", "process-999")
        
        # Verify sys.exit was called with code 1
        assert excinfo.value.code == 1
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "operator": "and",
                    "nestedExpression": [
                        {
                            "argument": ["atom-999"],
                            "operator": "EQUALS",
                            "property": "atomId"
                        },
                        {
                            "argument": ["process-999"],
                            "operator": "EQUALS",
                            "property": "processId"
                        }
                    ]
                }
            }
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/ProcessSchedules/query",
            payload=expected_payload
        )


class TestUpdateProcessSchedules:
    """Test cases for the update_process_schedules function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_update_process_schedules_clear_schedules(self, mock_atomsphere_request):
        """Test update_process_schedules clears schedules when schedules is None."""
        # Create mock response object
        mock_response = Mock()
        mock_response.text = ""
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function with None schedules (should clear)
        result = boomi_cicd.update_process_schedules("comp-123", "conceptual-456", "atom-789", None)
        
        # Assertions
        assert result is True
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "processId": "comp-123",
            "atomId": "atom-789",
            "id": "conceptual-456",
            "Schedule": []
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/ProcessSchedules/conceptual-456/update",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_update_process_schedules_with_single_schedule(self, mock_atomsphere_request):
        """Test update_process_schedules with a single schedule."""
        # Create mock response object
        mock_response = Mock()
        mock_response.text = ""
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function with a single schedule
        schedule_string = "0 8 * * * *"  # Daily at 8 AM
        result = boomi_cicd.update_process_schedules("comp-456", "conceptual-789", "atom-012", schedule_string)
        
        # Assertions
        assert result is True
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "processId": "comp-456",
            "atomId": "atom-012",
            "id": "conceptual-789",
            "Schedule": [
                {
                    "@type": "Schedule",
                    "minutes": "0",
                    "hours": "8", 
                    "daysOfWeek": "*",
                    "daysOfMonth": "*",
                    "months": "*",
                    "years": "*"
                }
            ]
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/ProcessSchedules/conceptual-789/update",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_update_process_schedules_with_multiple_schedules(self, mock_atomsphere_request):
        """Test update_process_schedules with multiple schedules."""
        # Create mock response object
        mock_response = Mock()
        mock_response.text = ""
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function with multiple schedules
        schedule_string = "0 8 * * * *; 0 18 * * * *"  # Daily at 8 AM and 6 PM
        result = boomi_cicd.update_process_schedules("comp-789", "conceptual-012", "atom-345", schedule_string)
        
        # Assertions
        assert result is True
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "processId": "comp-789",
            "atomId": "atom-345",
            "id": "conceptual-012",
            "Schedule": [
                {
                    "@type": "Schedule",
                    "minutes": "0",
                    "hours": "8",
                    "daysOfWeek": "*",
                    "daysOfMonth": "*", 
                    "months": "*",
                    "years": "*"
                },
                {
                    "@type": "Schedule",
                    "minutes": "0",
                    "hours": "18",
                    "daysOfWeek": "*",
                    "daysOfMonth": "*",
                    "months": "*", 
                    "years": "*"
                }
            ]
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/ProcessSchedules/conceptual-012/update",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_update_process_schedules_invalid_schedule_format(self, mock_atomsphere_request):
        """Test update_process_schedules exits with invalid schedule format."""
        # Test the function with invalid schedule format (missing fields)
        invalid_schedule = "0 8 * *"  # Only 4 fields instead of 6
        
        # Test should raise SystemExit due to sys.exit(1) call
        with pytest.raises(SystemExit) as excinfo:
            boomi_cicd.update_process_schedules("comp-invalid", "conceptual-invalid", "atom-invalid", invalid_schedule)
        
        # Verify sys.exit was called with code 1
        assert excinfo.value.code == 1
        
        # Verify atomsphere_request was not called due to early exit
        mock_atomsphere_request.assert_not_called()

    @patch('boomi_cicd.atomsphere_request')
    def test_update_process_schedules_with_whitespace(self, mock_atomsphere_request):
        """Test update_process_schedules handles schedules with extra whitespace."""
        # Create mock response object
        mock_response = Mock()
        mock_response.text = ""
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function with schedule containing extra whitespace
        schedule_string = " 0 12 * * * * ; 30 14 * * * * "
        result = boomi_cicd.update_process_schedules("comp-whitespace", "conceptual-whitespace", "atom-whitespace", schedule_string)
        
        # Assertions
        assert result is True
        
        # Verify the atomsphere_request was called with correct parameters (whitespace stripped)
        expected_payload = {
            "processId": "comp-whitespace",
            "atomId": "atom-whitespace",
            "id": "conceptual-whitespace",
            "Schedule": [
                {
                    "@type": "Schedule",
                    "minutes": "0",
                    "hours": "12",
                    "daysOfWeek": "*",
                    "daysOfMonth": "*",
                    "months": "*",
                    "years": "*"
                },
                {
                    "@type": "Schedule", 
                    "minutes": "30",
                    "hours": "14",
                    "daysOfWeek": "*",
                    "daysOfMonth": "*",
                    "months": "*",
                    "years": "*"
                }
            ]
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/ProcessSchedules/conceptual-whitespace/update",
            payload=expected_payload
        )