import json
import pytest
from unittest.mock import Mock, patch
import boomi_cicd


class TestQueryProcessScheduleStatus:
    """Test cases for the query_process_schedule_status function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_query_process_schedule_status_success(self, mock_atomsphere_request):
        """Test query_process_schedule_status returns correct conceptual ID when successful."""
        # Mock response data
        mock_response_data = {
            "@type": "QueryResult",
            "result": [
                {
                    "@type": "ProcessScheduleStatus",
                    "id": "conceptual-schedule-123",
                    "processId": "process-456",
                    "atomId": "atom-789",
                    "enabled": True
                }
            ],
            "numberOfResults": 1
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.query_process_schedule_status("atom-789", "process-456")
        
        # Assertions
        assert result == "conceptual-schedule-123"
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "operator": "and",
                    "nestedExpression": [
                        {
                            "argument": ["atom-789"],
                            "operator": "EQUALS",
                            "property": "atomId"
                        },
                        {
                            "argument": ["process-456"],
                            "operator": "EQUALS",
                            "property": "processId"
                        }
                    ]
                }
            }
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/ProcessScheduleStatus/query",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_query_process_schedule_status_not_deployed(self, mock_atomsphere_request):
        """Test query_process_schedule_status exits when process is not deployed."""
        # Mock response data with no results
        mock_response_data = {
            "@type": "QueryResult",
            "result": [],
            "numberOfResults": 0
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function - should raise SystemExit due to sys.exit(1)
        with pytest.raises(SystemExit) as excinfo:
            boomi_cicd.query_process_schedule_status("atom-nonexistent", "process-nonexistent")
        
        # Verify sys.exit was called with code 1
        assert excinfo.value.code == 1
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "operator": "and",
                    "nestedExpression": [
                        {
                            "argument": ["atom-nonexistent"],
                            "operator": "EQUALS",
                            "property": "atomId"
                        },
                        {
                            "argument": ["process-nonexistent"],
                            "operator": "EQUALS",
                            "property": "processId"
                        }
                    ]
                }
            }
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/ProcessScheduleStatus/query",
            payload=expected_payload
        )


class TestUpdateProcessScheduleStatus:
    """Test cases for the update_process_schedule_status function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_update_process_schedule_status_enable(self, mock_atomsphere_request):
        """Test update_process_schedule_status enables process schedule."""
        # Create mock response object
        mock_response = Mock()
        mock_response.text = ""
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function with enabled=True
        result = boomi_cicd.update_process_schedule_status("comp-123", "conceptual-456", "atom-789", True)
        
        # Assertions
        assert result is True
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "processId": "comp-123",
            "atomId": "atom-789",
            "id": "conceptual-456",
            "enabled": True
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/ProcessScheduleStatus/conceptual-456/update",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_update_process_schedule_status_disable(self, mock_atomsphere_request):
        """Test update_process_schedule_status disables process schedule."""
        # Create mock response object
        mock_response = Mock()
        mock_response.text = ""
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function with enabled=False
        result = boomi_cicd.update_process_schedule_status("comp-456", "conceptual-789", "atom-012", False)
        
        # Assertions
        assert result is True
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "processId": "comp-456",
            "atomId": "atom-012",
            "id": "conceptual-789",
            "enabled": False
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/ProcessScheduleStatus/conceptual-789/update",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_update_process_schedule_status_with_different_ids(self, mock_atomsphere_request):
        """Test update_process_schedule_status with various ID formats."""
        # Create mock response object
        mock_response = Mock()
        mock_response.text = ""
        mock_atomsphere_request.return_value = mock_response
        
        # Test with different ID formats
        component_id = "component-abc-def-123"
        conceptual_id = "schedule-status-456-789"
        atom_id = "atom-xyz-890"
        
        result = boomi_cicd.update_process_schedule_status(component_id, conceptual_id, atom_id, True)
        
        # Assertions
        assert result is True
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "processId": component_id,
            "atomId": atom_id,
            "id": conceptual_id,
            "enabled": True
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path=f"/ProcessScheduleStatus/{conceptual_id}/update",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_update_process_schedule_status_boolean_values(self, mock_atomsphere_request):
        """Test update_process_schedule_status with explicit boolean values."""
        # Create mock response object
        mock_response = Mock()
        mock_response.text = ""
        mock_atomsphere_request.return_value = mock_response
        
        # Test with explicit False boolean
        result = boomi_cicd.update_process_schedule_status("test-comp", "test-conceptual", "test-atom", False)
        
        # Assertions
        assert result is True
        
        # Verify the enabled field is exactly False (not a string or other falsy value)
        expected_payload = {
            "processId": "test-comp",
            "atomId": "test-atom", 
            "id": "test-conceptual",
            "enabled": False
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/ProcessScheduleStatus/test-conceptual/update",
            payload=expected_payload
        )
        
        # Verify that enabled is boolean type, not string
        call_args = mock_atomsphere_request.call_args
        payload = call_args[1]["payload"]
        assert isinstance(payload["enabled"], bool)
        assert payload["enabled"] is False