import json
import pytest
from unittest.mock import Mock, patch
import boomi_cicd


class TestQueryMergeRequest:
    """Test cases for the query_merge_request function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_query_merge_request_with_source_branch(self, mock_atomsphere_request):
        """Test query_merge_request with source branch ID only."""
        # Mock response data
        mock_response_data = {
            "@type": "QueryResult",
            "result": [
                {
                    "@type": "MergeRequest",
                    "id": "test-merge-request-id",
                    "sourceBranchId": "source-branch-123",
                    "destinationBranchId": "dest-branch-456",
                    "stage": "REVIEWING"
                }
            ],
            "numberOfResults": 1
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.query_merge_request(source_branch_id="source-branch-123")
        
        # Assertions
        assert result == mock_response_data
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "operator": "and",
                    "nestedExpression": [
                        {
                            "argument": ["source-branch-123"],
                            "operator": "EQUALS",
                            "property": "sourceBranchId"
                        }
                    ]
                }
            }
        }
        
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/MergeRequest/query",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_query_merge_request_with_destination_branch(self, mock_atomsphere_request):
        """Test query_merge_request with destination branch ID only."""
        # Mock response data
        mock_response_data = {
            "@type": "QueryResult",
            "result": [],
            "numberOfResults": 0
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.query_merge_request(destination_branch_id="dest-branch-456")
        
        # Assertions
        assert result == mock_response_data
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "operator": "and",
                    "nestedExpression": [
                        {
                            "argument": ["dest-branch-456"],
                            "operator": "EQUALS",
                            "property": "destinationBranchId"
                        }
                    ]
                }
            }
        }
        
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/MergeRequest/query",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_query_merge_request_with_all_parameters(self, mock_atomsphere_request):
        """Test query_merge_request with all parameters."""
        # Mock response data
        mock_response_data = {
            "@type": "QueryResult",
            "result": [
                {
                    "@type": "MergeRequest",
                    "id": "test-merge-request-id",
                    "sourceBranchId": "source-branch-123",
                    "destinationBranchId": "dest-branch-456",
                    "stage": "MERGED"
                }
            ],
            "numberOfResults": 1
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.query_merge_request(
            source_branch_id="source-branch-123",
            destination_branch_id="dest-branch-456",
            stage="MERGED"
        )
        
        # Assertions
        assert result == mock_response_data
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "operator": "and",
                    "nestedExpression": [
                        {
                            "argument": ["source-branch-123"],
                            "operator": "EQUALS",
                            "property": "sourceBranchId"
                        },
                        {
                            "argument": ["dest-branch-456"],
                            "operator": "EQUALS",
                            "property": "destinationBranchId"
                        },
                        {
                            "argument": ["MERGED"],
                            "operator": "EQUALS",
                            "property": "stage"
                        }
                    ]
                }
            }
        }
        
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/MergeRequest/query",
            payload=expected_payload
        )

    def test_query_merge_request_no_parameters(self):
        """Test query_merge_request raises ValueError when no parameters provided."""
        with pytest.raises(ValueError, match="Either source_branch_id or destionation_branch_id must be provided."):
            boomi_cicd.query_merge_request()

    def test_query_merge_request_empty_parameters(self):
        """Test query_merge_request raises ValueError when empty parameters provided."""
        with pytest.raises(ValueError, match="Either source_branch_id or destionation_branch_id must be provided."):
            boomi_cicd.query_merge_request(source_branch_id="", destination_branch_id="")


class TestGetMergeRequest:
    """Test cases for the get_merge_request function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_get_merge_request_success(self, mock_atomsphere_request):
        """Test get_merge_request returns correct merge request data."""
        # Mock response data
        mock_response_data = {
            "@type": "MergeRequest",
            "id": "test-merge-request-id",
            "sourceBranchId": "source-branch-123",
            "destinationBranchId": "dest-branch-456",
            "stage": "REVIEWING",
            "strategy": "OVERRIDE",
            "priorityBranch": "SOURCE"
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.get_merge_request("test-merge-request-id")
        
        # Assertions
        assert result == mock_response_data
        
        # Verify the atomsphere_request was called with correct parameters
        mock_atomsphere_request.assert_called_once_with(
            method="get",
            resource_path="/MergeRequest/test-merge-request-id"
        )

    def test_get_merge_request_no_id(self):
        """Test get_merge_request raises ValueError when no ID provided."""
        with pytest.raises(ValueError, match="merge_request_id must be provided."):
            boomi_cicd.get_merge_request("")

    def test_get_merge_request_none_id(self):
        """Test get_merge_request raises ValueError when None ID provided."""
        with pytest.raises(ValueError, match="merge_request_id must be provided."):
            boomi_cicd.get_merge_request(None)


class TestCreateMergeRequest:
    """Test cases for the create_merge_request function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_create_merge_request_success(self, mock_atomsphere_request):
        """Test create_merge_request returns merge request ID on success."""
        # Mock response data
        mock_response_data = {
            "@type": "MergeRequest",
            "id": "new-merge-request-id"
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.create_merge_request(
            source_branch_id="source-branch-123",
            destination_branch_id="dest-branch-456",
            strategy="OVERRIDE",
            priority_branch="SOURCE"
        )
        
        # Assertions
        assert result == "new-merge-request-id"
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "sourceBranchId": "source-branch-123",
            "destinationBranchId": "dest-branch-456",
            "strategy": "OVERRIDE",
            "priorityBranch": "SOURCE"
        }
        
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/MergeRequest",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_create_merge_request_conflict_resolve_strategy(self, mock_atomsphere_request):
        """Test create_merge_request with CONFLICT_RESOLVE strategy."""
        # Mock response data
        mock_response_data = {
            "@type": "MergeRequest",
            "id": "conflict-resolve-merge-request-id"
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.create_merge_request(
            source_branch_id="source-branch-123",
            destination_branch_id="dest-branch-456",
            strategy="CONFLICT_RESOLVE",
            priority_branch="DESTINATION"
        )
        
        # Assertions
        assert result == "conflict-resolve-merge-request-id"
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "sourceBranchId": "source-branch-123",
            "destinationBranchId": "dest-branch-456",
            "strategy": "CONFLICT_RESOLVE",
            "priorityBranch": "DESTINATION"
        }
        
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/MergeRequest",
            payload=expected_payload
        )

    def test_create_merge_request_missing_source_branch(self):
        """Test create_merge_request raises ValueError when source branch ID is missing."""
        with pytest.raises(ValueError, match="Both source_branch_id and destionation_branch_id must be provided."):
            boomi_cicd.create_merge_request(
                source_branch_id="",
                destination_branch_id="dest-branch-456",
                strategy="OVERRIDE",
                priority_branch="SOURCE"
            )

    def test_create_merge_request_missing_destination_branch(self):
        """Test create_merge_request raises ValueError when destination branch ID is missing."""
        with pytest.raises(ValueError, match="Both source_branch_id and destionation_branch_id must be provided."):
            boomi_cicd.create_merge_request(
                source_branch_id="source-branch-123",
                destination_branch_id=None,
                strategy="OVERRIDE",
                priority_branch="SOURCE"
            )

    def test_create_merge_request_invalid_strategy(self):
        """Test create_merge_request raises ValueError with invalid strategy."""
        with pytest.raises(ValueError, match="Invalid strategy. Must be 'OVERRIDE' or 'CONFLICT_RESOLVE'."):
            boomi_cicd.create_merge_request(
                source_branch_id="source-branch-123",
                destination_branch_id="dest-branch-456",
                strategy="INVALID_STRATEGY",
                priority_branch="SOURCE"
            )

    def test_create_merge_request_invalid_priority_branch(self):
        """Test create_merge_request raises ValueError with invalid priority branch."""
        with pytest.raises(ValueError, match="Invalid priority_branch. Must be 'SOURCE' or 'DESTINATION'."):
            boomi_cicd.create_merge_request(
                source_branch_id="source-branch-123",
                destination_branch_id="dest-branch-456",
                strategy="OVERRIDE",
                priority_branch="INVALID_PRIORITY"
            )

    @patch('boomi_cicd.atomsphere_request')
    def test_create_merge_request_api_failure(self, mock_atomsphere_request):
        """Test create_merge_request raises ValueError when API response lacks ID."""
        # Mock response data without ID
        mock_response_data = {
            "@type": "Error",
            "message": "Failed to create merge request"
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        with pytest.raises(ValueError, match="Merge request creation failed"):
            boomi_cicd.create_merge_request(
                source_branch_id="source-branch-123",
                destination_branch_id="dest-branch-456",
                strategy="OVERRIDE",
                priority_branch="SOURCE"
            )


class TestExecuteMergeRequest:
    """Test cases for the execute_merge_request function."""

    @patch('boomi_cicd.util.merge_request.get_merge_request')
    @patch('boomi_cicd.atomsphere_request')
    def test_execute_merge_request_merge_action_reviewing_stage(self, mock_atomsphere_request, mock_get_merge_request):
        """Test execute_merge_request with MERGE action in REVIEWING stage."""
        # Mock get_merge_request response
        mock_get_merge_request.return_value = {"stage": "REVIEWING"}
        
        # Mock execute response
        mock_response_data = {
            "@type": "MergeRequestExecutionResult",
            "id": "test-merge-request-id",
            "status": "SUCCESS"
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.execute_merge_request("test-merge-request-id", "MERGE")
        
        # Assertions
        assert result == mock_response_data
        
        # Verify the get_merge_request was called
        mock_get_merge_request.assert_called_once_with("test-merge-request-id")
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "id": "test-merge-request-id",
            "mergeRequestAction": "MERGE"
        }
        
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/MergeRequest/execute/test-merge-request-id",
            payload=expected_payload
        )

    @patch('boomi_cicd.util.merge_request.get_merge_request')
    @patch('boomi_cicd.atomsphere_request')
    def test_execute_merge_request_merge_action_failed_to_merge_stage(self, mock_atomsphere_request, mock_get_merge_request):
        """Test execute_merge_request with MERGE action in FAILED_TO_MERGE stage."""
        # Mock get_merge_request response
        mock_get_merge_request.return_value = {"stage": "FAILED_TO_MERGE"}
        
        # Mock execute response
        mock_response_data = {
            "@type": "MergeRequestExecutionResult",
            "id": "test-merge-request-id",
            "status": "SUCCESS"
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.execute_merge_request("test-merge-request-id", "MERGE")
        
        # Assertions
        assert result == mock_response_data
        mock_get_merge_request.assert_called_once_with("test-merge-request-id")

    @patch('boomi_cicd.util.merge_request.get_merge_request')
    @patch('boomi_cicd.atomsphere_request')
    def test_execute_merge_request_revert_action_merged_stage(self, mock_atomsphere_request, mock_get_merge_request):
        """Test execute_merge_request with REVERT action in MERGED stage."""
        # Mock get_merge_request response
        mock_get_merge_request.return_value = {"stage": "MERGED"}
        
        # Mock execute response
        mock_response_data = {
            "@type": "MergeRequestExecutionResult",
            "id": "test-merge-request-id",
            "status": "SUCCESS"
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.execute_merge_request("test-merge-request-id", "REVERT")
        
        # Assertions
        assert result == mock_response_data
        mock_get_merge_request.assert_called_once_with("test-merge-request-id")

    @patch('boomi_cicd.util.merge_request.get_merge_request')
    @patch('boomi_cicd.atomsphere_request')
    def test_execute_merge_request_retry_drafting_action_failed_to_draft_stage(self, mock_atomsphere_request, mock_get_merge_request):
        """Test execute_merge_request with RETRY_DRAFTING action in FAILED_TO_DRAFT stage."""
        # Mock get_merge_request response
        mock_get_merge_request.return_value = {"stage": "FAILED_TO_DRAFT"}
        
        # Mock execute response
        mock_response_data = {
            "@type": "MergeRequestExecutionResult",
            "id": "test-merge-request-id",
            "status": "SUCCESS"
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.execute_merge_request("test-merge-request-id", "RETRY_DRAFTING")
        
        # Assertions
        assert result == mock_response_data
        mock_get_merge_request.assert_called_once_with("test-merge-request-id")

    def test_execute_merge_request_no_id(self):
        """Test execute_merge_request raises ValueError when no ID provided."""
        with pytest.raises(ValueError, match="merge_request_id must be provided."):
            boomi_cicd.execute_merge_request("", "MERGE")

    def test_execute_merge_request_invalid_action(self):
        """Test execute_merge_request raises ValueError with invalid action."""
        with pytest.raises(ValueError, match="Invalid action. Must be 'MERGE', 'REVERT', or 'RETRY_DRAFTING'."):
            boomi_cicd.execute_merge_request("test-merge-request-id", "INVALID_ACTION")

    @patch('boomi_cicd.util.merge_request.get_merge_request')
    def test_execute_merge_request_merge_invalid_stage(self, mock_get_merge_request):
        """Test execute_merge_request raises ValueError when MERGE action is used with invalid stage."""
        # Mock get_merge_request response with invalid stage
        mock_get_merge_request.return_value = {"stage": "DRAFTING"}
        
        with pytest.raises(ValueError, match="Merge request cannot be merged in its current stage: DRAFTING"):
            boomi_cicd.execute_merge_request("test-merge-request-id", "MERGE")

    @patch('boomi_cicd.util.merge_request.get_merge_request')
    def test_execute_merge_request_revert_invalid_stage(self, mock_get_merge_request):
        """Test execute_merge_request raises ValueError when REVERT action is used with invalid stage."""
        # Mock get_merge_request response with invalid stage
        mock_get_merge_request.return_value = {"stage": "REVIEWING"}
        
        with pytest.raises(ValueError, match="Merge request cannot be reverted in its current stage: REVIEWING"):
            boomi_cicd.execute_merge_request("test-merge-request-id", "REVERT")

    @patch('boomi_cicd.util.merge_request.get_merge_request')
    def test_execute_merge_request_retry_drafting_invalid_stage(self, mock_get_merge_request):
        """Test execute_merge_request raises ValueError when RETRY_DRAFTING action is used with invalid stage."""
        # Mock get_merge_request response with invalid stage
        mock_get_merge_request.return_value = {"stage": "REVIEWING"}
        
        with pytest.raises(ValueError, match="Merge request drafting cannot be retried in its current stage: REVIEWING"):
            boomi_cicd.execute_merge_request("test-merge-request-id", "RETRY_DRAFTING")