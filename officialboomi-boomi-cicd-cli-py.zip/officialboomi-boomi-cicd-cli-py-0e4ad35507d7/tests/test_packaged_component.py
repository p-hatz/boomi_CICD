import json
import pytest
from unittest.mock import Mock, patch
import boomi_cicd


class TestCreatePackagedComponent:
    """Test cases for the create_packaged_component function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_create_packaged_component_success(self, mock_atomsphere_request):
        """Test create_packaged_component returns correct package ID when successful."""
        # Mock response data
        mock_response_data = {
            "@type": "PackagedComponent",
            "packageId": "pkg-12345-67890",
            "componentId": "comp-123",
            "packageVersion": "v1.0.0",
            "notes": "Test package",
            "createdDate": "2025-12-21T10:30:00Z"
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.create_packaged_component("comp-123", "v1.0.0", "Test package")
        
        # Assertions
        assert result == "pkg-12345-67890"
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "componentId": "comp-123",
            "packageVersion": "v1.0.0",
            "notes": "Test package"
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/PackagedComponent",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_create_packaged_component_with_branch_id(self, mock_atomsphere_request):
        """Test create_packaged_component with branch ID."""
        # Mock response data
        mock_response_data = {
            "@type": "PackagedComponent",
            "packageId": "pkg-98765-43210",
            "componentId": "comp-456",
            "packageVersion": "v2.0.0",
            "notes": "Branch package",
            "branchId": "branch-789"
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function with branch_id
        result = boomi_cicd.create_packaged_component("comp-456", "v2.0.0", "Branch package", "branch-789")
        
        # Assertions
        assert result == "pkg-98765-43210"
        
        # Verify the atomsphere_request was called with correct parameters including branchId
        expected_payload = {
            "componentId": "comp-456",
            "packageVersion": "v2.0.0",
            "notes": "Branch package",
            "branchId": "branch-789"
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/PackagedComponent",
            payload=expected_payload
        )


class TestQueryPackagedComponent:
    """Test cases for the query_packaged_component function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_query_packaged_component_found(self, mock_atomsphere_request):
        """Test query_packaged_component returns package ID when component exists."""
        # Mock response data with results
        mock_response_data = {
            "@type": "QueryResult",
            "result": [
                {
                    "@type": "PackagedComponent",
                    "packageId": "pkg-existing-123",
                    "componentId": "comp-789",
                    "packageVersion": "v1.5.0"
                }
            ],
            "numberOfResults": 1
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.query_packaged_component("comp-789", "v1.5.0")
        
        # Assertions
        assert result == "pkg-existing-123"
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "operator": "and",
                    "nestedExpression": [
                        {
                            "argument": ["comp-789"],
                            "operator": "EQUALS",
                            "property": "componentId"
                        },
                        {
                            "argument": ["v1.5.0"],
                            "operator": "EQUALS",
                            "property": "packageVersion"
                        }
                    ]   
                }
            }
        }
        
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/PackagedComponent/query",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_query_packaged_component_not_found(self, mock_atomsphere_request):
        """Test query_packaged_component returns empty string when component not found."""
        # Mock response data with no results
        mock_response_data = {
            "@type": "QueryResult",
            "result": [],
            "numberOfResults": 0
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.query_packaged_component("comp-nonexistent", "v9.9.9")
        
        # Assertions
        assert result == ""
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "operator": "and",
                    "nestedExpression": [
                        {
                            "argument": ["comp-nonexistent"],
                            "operator": "EQUALS",
                            "property": "componentId"
                        },
                        {
                            "argument": ["v9.9.9"],
                            "operator": "EQUALS",
                            "property": "packageVersion"
                        }
                    ]   
                }
            }
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/PackagedComponent/query",
            payload=expected_payload
        )
