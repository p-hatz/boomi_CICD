import json
import pytest
from unittest.mock import Mock, patch
import boomi_cicd
from boomi_cicd.util.branch import BranchNotFoundError, MultipleBranchesFoundError


class TestGetBranchId:
    """Test cases for the get_branch_id function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_get_branch_id_success(self, mock_atomsphere_request):
        """Test get_branch_id returns correct branch ID when branch exists."""
        # Mock response data
        mock_response_data = {
            "@type": "QueryResult",
            "result": [
                {
                    "@type": "Branch",
                    "id": "Qjo1Mjk3NjM",
                    "name": "dev"
                }
            ],
            "numberOfResults": 1
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.json.return_value = mock_response_data
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.get_branch_id("dev")
        
        # Assertions
        assert result == "Qjo1Mjk3NjM"
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "QueryFilter": {
                "expression": {
                    "argument": ["dev"],
                    "operator": "EQUALS",
                    "property": "name"
                }
            }
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/Branch/query", 
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_get_branch_id_multiple_branches_returns_exact_match(self, mock_atomsphere_request):
        """Test get_branch_id throws error when searched branch doesn't exist among multiple branches."""
        # Mock response with multiple branches
        mock_response_data = {
            "@type": "QueryResult",
            "result": [
                {
                    "@type": "Branch",
                    "id": "QjoEuNmKJA",
                    "name": "dev"
                },
                {
                    "@type": "Branch",
                    "id": "QjoMnVxCpL",
                    "name": "dev2"
                },
                {
                    "@type": "Branch",
                    "id": "QjoRtYuIoP",
                    "name": "development"
                }
            ],
            "numberOfResults": 3
        }
        
        mock_response = Mock()
        mock_response.json.return_value = mock_response_data
        mock_atomsphere_request.return_value = mock_response
        
        # Test that BranchNotFoundError is raised when searching for non-existent branch
        with pytest.raises(MultipleBranchesFoundError, match="Multiple branches found with the same name. Branch name in query: 'staging'"):
            boomi_cicd.get_branch_id("staging")

    @patch('boomi_cicd.atomsphere_request')
    def test_get_branch_id_branch_not_found(self, mock_atomsphere_request):
        """Test get_branch_id raises BranchNotFoundError when branch doesn't exist."""
        # Mock response with no matching branches
        mock_response_data = {
            "@type": "QueryResult",
            "result": [
                {
                    "@type": "Branch",
                    "id": "QjoProdBrn",
                    "name": "prod"
                }
            ],
            "numberOfResults": 1
        }
        
        mock_response = Mock()
        mock_response.json.return_value = mock_response_data
        mock_atomsphere_request.return_value = mock_response
        
        # Test that BranchNotFoundError is raised
        with pytest.raises(BranchNotFoundError, match="Branch 'nonexistent' not found"):
            boomi_cicd.get_branch_id("nonexistent")

    @patch('boomi_cicd.atomsphere_request')  
    def test_get_branch_id_empty_result(self, mock_atomsphere_request):
        """Test get_branch_id raises BranchNotFoundError when API returns empty result."""
        # Mock response with empty result
        mock_response_data = {
            "@type": "QueryResult",
            "result": [],
            "numberOfResults": 0
        }
        
        mock_response = Mock()
        mock_response.json.return_value = mock_response_data
        mock_atomsphere_request.return_value = mock_response
        
        # Test that BranchNotFoundError is raised
        with pytest.raises(BranchNotFoundError, match="Branch 'test' not found"):
            boomi_cicd.get_branch_id("test")

    @patch('boomi_cicd.atomsphere_request')
    def test_get_branch_id_no_result_key(self, mock_atomsphere_request):
        """Test get_branch_id handles response without 'result' key gracefully."""
        # Mock response without 'result' key
        mock_response_data = {
            "@type": "QueryResult",
            "numberOfResults": 0
        }
        
        mock_response = Mock()
        mock_response.json.return_value = mock_response_data
        mock_atomsphere_request.return_value = mock_response
        
        # Test that BranchNotFoundError is raised (empty list from .get())
        with pytest.raises(BranchNotFoundError, match="Branch 'test' not found"):
            boomi_cicd.get_branch_id("test")

    @patch('boomi_cicd.atomsphere_request')
    def test_get_branch_id_branch_missing_id(self, mock_atomsphere_request):
        """Test get_branch_id handles branches without ID field."""
        # Mock response with branch missing id field
        mock_response_data = {
            "@type": "QueryResult",
            "result": [
                {
                    "@type": "Branch",
                    "name": "test"
                    # Missing 'id' field
                }
            ],
            "numberOfResults": 1
        }
        
        mock_response = Mock()
        mock_response.json.return_value = mock_response_data
        mock_atomsphere_request.return_value = mock_response
        
        # Should return None when id is missing (branch.get("id") returns None)
        with pytest.raises(BranchNotFoundError, match="Branch 'test' not found"):
            boomi_cicd.get_branch_id("test")


class TestCreateBranch:
    """Test cases for the create_branch function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_create_branch_success(self, mock_atomsphere_request):
        """Test create_branch successfully creates a branch and returns branch ID."""
        # Mock response data
        mock_response_data = {
            "@type": "Branch",
            "id": "QjoNewBranch123",
            "name": "feature-branch",
            "description": "New feature branch",
            "createdBy": "user@boomi.com",
            "createdDate": "2025-12-20T18:30:00Z",
            "parentId": "QjoParent456",
            "ready": True,
            "deleted": False,
            "stage": "NORMAL"
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.json.return_value = mock_response_data
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.create_branch("feature-branch", "QjoParent456", "New feature branch")
        
        # Assertions
        assert result == "QjoNewBranch123"
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "name": "feature-branch",
            "description": "New feature branch",
            "parentId": "QjoParent456"
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/Branch",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_create_branch_default_description(self, mock_atomsphere_request):
        """Test create_branch with default empty description."""
        # Mock response data
        mock_response_data = {
            "@type": "Branch",
            "id": "QjoNewBranch456",
            "name": "dev-branch",
            "description": "",
            "createdBy": "user@boomi.com",
            "createdDate": "2025-12-20T18:30:00Z",
            "parentId": "QjoParent789",
            "ready": True,
            "deleted": False,
            "stage": "NORMAL"
        }
        
        mock_response = Mock()
        mock_response.json.return_value = mock_response_data
        mock_atomsphere_request.return_value = mock_response
        
        # Test without description parameter (should use default empty string)
        result = boomi_cicd.create_branch("dev-branch", "QjoParent789")
        
        assert result == "QjoNewBranch456"
        
        # Verify the atomsphere_request was called with empty description
        expected_payload = {
            "name": "dev-branch",
            "description": "",
            "parentId": "QjoParent789"
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/Branch",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_create_branch_missing_id(self, mock_atomsphere_request):
        """Test create_branch throws exception when response is missing ID field."""
        # Mock response without 'id' field
        mock_response_data = {
            "@type": "Branch",
            "name": "test-branch",
            "description": "Test branch",
            "createdBy": "user@boomi.com",
            "createdDate": "2025-12-20T18:30:00Z",
            "parentId": "QjoParent123",
            "ready": True,
            "deleted": False,
            "stage": "NORMAL"
            # Missing 'id' field
        }
        
        mock_response = Mock()
        mock_response.json.return_value = mock_response_data
        mock_atomsphere_request.return_value = mock_response
        
        # Should throw exception when id is missing
        with pytest.raises(Exception, match="Branch creation failed: missing branch ID in response."):
            boomi_cicd.create_branch("test-branch", "QjoParent123", "Test branch")

    @patch('boomi_cicd.atomsphere_request')
    def test_create_branch_empty_response(self, mock_atomsphere_request):
        """Test create_branch handles empty response."""
        # Mock empty response
        mock_response_data = {}
        
        mock_response = Mock()
        mock_response.json.return_value = mock_response_data
        mock_atomsphere_request.return_value = mock_response
        
        # Should throw exception when response is empty
        with pytest.raises(Exception, match="Branch creation failed: missing branch ID in response."):
            result = boomi_cicd.create_branch("empty-test", "QjoParent999")

    @patch('boomi_cicd.atomsphere_request')
    def test_create_branch_with_special_characters(self, mock_atomsphere_request):
        """Test create_branch handles branch names with special characters."""
        # Mock response data
        mock_response_data = {
            "@type": "Branch",
            "id": "QjoSpecialBranch",
            "name": "feature/special-branch_v1.0",
            "description": "Branch with special chars & symbols",
            "createdBy": "user@boomi.com",
            "createdDate": "2025-12-20T18:30:00Z",
            "parentId": "QjoParentSpecial",
            "ready": True,
            "deleted": False,
            "stage": "NORMAL"
        }
        
        mock_response = Mock()
        mock_response.json.return_value = mock_response_data
        mock_atomsphere_request.return_value = mock_response
        
        # Test with special characters in name and description
        result = boomi_cicd.create_branch(
            "feature/special-branch_v1.0", 
            "QjoParentSpecial", 
            "Branch with special chars & symbols"
        )
        
        assert result == "QjoSpecialBranch"
        
        # Verify correct payload structure
        expected_payload = {
            "name": "feature/special-branch_v1.0",
            "description": "Branch with special chars & symbols",
            "parentId": "QjoParentSpecial"
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/Branch",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_create_branch_long_description(self, mock_atomsphere_request):
        """Test create_branch with very long description."""
        long_description = "A" * 1000  # 1000 character description
        
        mock_response_data = {
            "@type": "Branch",
            "id": "QjoLongDescBranch",
            "name": "long-desc-branch",
            "description": long_description,
            "createdBy": "user@boomi.com",
            "createdDate": "2025-12-20T18:30:00Z",
            "parentId": "QjoParentLong",
            "ready": True,
            "deleted": False,
            "stage": "NORMAL"
        }
        
        mock_response = Mock()
        mock_response.json.return_value = mock_response_data
        mock_atomsphere_request.return_value = mock_response
        
        result = boomi_cicd.create_branch("long-desc-branch", "QjoParentLong", long_description)
        
        assert result == "QjoLongDescBranch"
        
        # Verify long description is passed correctly
        expected_payload = {
            "name": "long-desc-branch",
            "description": long_description,
            "parentId": "QjoParentLong"
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/Branch",
            payload=expected_payload
        )

