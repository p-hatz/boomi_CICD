import json
import pytest
from unittest.mock import Mock, patch
import boomi_cicd


class TestCreateExecutionRequest:
    """Test cases for the create_execution_request function."""

    @patch('boomi_cicd.atomsphere_request')
    def test_create_execution_request_success(self, mock_atomsphere_request):
        """Test create_execution_request returns correct request ID when successful."""
        # Mock response data
        mock_response_data = {
            "@type": "ExecutionRequest",
            "processId": "7b1e4d59-8d28-488b-988e-8f7826df1588",
            "atomId": "fa065728-2235-4583-87ea-a9d69762f10b",
            "requestId": "executionrecord-43ecd865-9b5e-4e15-ae1b-f8465dafc707",
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test the function
        result = boomi_cicd.create_execution_request(
            "fa065728-2235-4583-87ea-a9d69762f10b",
            "7b1e4d59-8d28-488b-988e-8f7826df1588",
        )
        
        # Assertions
        assert result == "executionrecord-43ecd865-9b5e-4e15-ae1b-f8465dafc707"
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "@type": "ExecutionRequest",
            "atomId": "fa065728-2235-4583-87ea-a9d69762f10b",
            "processId": "7b1e4d59-8d28-488b-988e-8f7826df1588",
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/ExecutionRequest",
            payload=expected_payload
        )

    @patch('boomi_cicd.atomsphere_request')
    def test_create_execution_request_failure(self, mock_atomsphere_request):
        """Test create_execution_request raises ValueError when requestId is missing."""
        # Mock response data without requestId
        mock_response_data = {
            "@type": "ExecutionRequest",
            "processId": "7b1e4d59-8d28-488b-988e-8f7826df1588",
            "atomId": "fa065728-2235-4583-87ea-a9d69762f10b",
        }
        
        # Create mock response object
        mock_response = Mock()
        mock_response.text = json.dumps(mock_response_data)
        mock_atomsphere_request.return_value = mock_response
        
        # Test that ValueError is raised
        with pytest.raises(ValueError, match="ExecutionRequest was not successful"):
            boomi_cicd.create_execution_request(
                "fa065728-2235-4583-87ea-a9d69762f10b",
                "7b1e4d59-8d28-488b-988e-8f7826df1588",
            )
        
        # Verify the atomsphere_request was called with correct parameters
        expected_payload = {
            "@type": "ExecutionRequest",
            "atomId": "fa065728-2235-4583-87ea-a9d69762f10b",
            "processId": "7b1e4d59-8d28-488b-988e-8f7826df1588",
        }
        mock_atomsphere_request.assert_called_once_with(
            method="post",
            resource_path="/ExecutionRequest",
            payload=expected_payload
        )
