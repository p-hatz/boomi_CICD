Example CICD Scripts
====================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   release-pipeline
   release-pipeline-dr
   environment-extensions-update
   component-xml-repo
   automated-testing
