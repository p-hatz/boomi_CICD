Release Pipeline Configuration
===============================

Example implementations of the release_pipeline script in common CICD tools.

.. toctree::
   :maxdepth: 1

   azure-devops
   github-actions
   jenkins