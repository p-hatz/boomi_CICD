.. module:: boomi_cicd.util.branch
   :noindex:
   :synopsis: Module for Branch related functions.

branch
======

`Boomi AtomSphere API:Branch Object <https://developer.boomi.com/docs/api/platformapi/Branch>`_

.. autofunction:: boomi_cicd.util.branch.get_branch_id

.. autofunction:: boomi_cicd.util.branch.create_branch

.. autoexception:: boomi_cicd.util.branch.BranchNotFoundError

.. autoexception:: boomi_cicd.util.branch.MultipleBranchesFoundError
