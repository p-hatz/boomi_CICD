.. module:: boomi_cicd.util.execution_request
   :noindex:
   :synopsis: Module for Execution Request AtomSphere API.

execution_request
======================

`Boomi AtomSphere API: Execution Request Object <https://help.boomi.com/docs/Atomsphere/Integration/AtomSphere%20API/int-Execution_Request_object_8d574574-44fe-4f0c-a843-69bd82fff245>`_

.. automodule:: boomi_cicd.util.execution_request
   :members:
   :undoc-members:
   :show-inheritance: