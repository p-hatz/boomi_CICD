.. module:: boomi_cicd.util.package_component_manifest
   :noindex:
   :synopsis: Module for Package Component Manifest AtomSphere API.

package_component_manifest
==========================

`Boomi AtomSphere API: Package Component Manifest Object <https://help.boomi.com/bundle/developer_apis/page/int-Packaged_Component_Manifest_object.html>`_

.. automodule:: boomi_cicd.util.package_component_manifest
   :members:
   :undoc-members:
   :show-inheritance: