.. module:: boomi_cicd.util.merge_request
   :noindex:
   :synopsis: Module for Merge Request related functions.

merge_request
=============

`Boomi AtomSphere API: MergeRequest Object <https://developer.boomi.com/docs/api/platformapi/MergeRequest>`_

You can use the Merge Request object to create and manage merge requests to merge changes in a development branch to another branch.

The Modifies or update a MergeRequest object is not implemented because of the complexity of the request. Create the payload and use atomsphere_request directly.

.. automodule:: boomi_cicd.util.merge_request
   :members:
   :undoc-members:
