.. module:: boomi_cicd.util.execution_record
   :noindex:
   :synopsis: Module for Execution Record AtomSphere API.

execution_record
======================

`Boomi AtomSphere API: Execution Record Object <https://help.boomi.com/docs/atomsphere/integration/atomsphere%20api/r-atm-atomsphere_api_6730e8e4-b2db-4e94-a653-82ae1d05c78e/>`_

.. automodule:: boomi_cicd.util.execution_record
   :members:
   :undoc-members:
   :show-inheritance: