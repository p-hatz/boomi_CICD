.. module:: boomi_cicd.util.execution_connector
   :noindex:
   :synopsis: Module for Excution Connector object.

execution_connector
===================

`Boomi AtomSphere API: Execution Record Object <https://help.boomi.com/docs/Atomsphere/Integration/AtomSphere%20API/int-Execution_connector_object_abb28203-9946-4c03-9205-8dc95b8f3f41>`_

.. automodule:: boomi_cicd.util.execution_connector
   :members:
   :undoc-members:
